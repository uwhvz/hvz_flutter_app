# hvz_flutter_app

Flutter Application for UWaterloo Humans vs Zombies. Development in progress.

To contribute, fork the repository, and submit a pull request.

Expected features:
- Link with website (blocked waiting for public API)
- Twitter feed
- Rules document
- Camera/Image storage functionality with possible QR code scanning for future supply codes (maybe)
