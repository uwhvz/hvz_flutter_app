import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hvz_flutter_app/applicationData.dart';

class MainWidget extends StatelessWidget {
  final appData = ApplicationData();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center();
  }
}